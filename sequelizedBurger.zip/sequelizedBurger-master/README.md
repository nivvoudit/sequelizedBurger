# sequelizedBurger
Sequelized Version of Burger App
